module.exports = [
  "#guthealth",
  "#weightlossjourney",
  "#wellnesstips",
  "#morningroutine",
  "#leanbiome",
  "#healthyliving",
  "#metabolismboost",
  "#healthhack",
  "#fitnessmotivation"
];