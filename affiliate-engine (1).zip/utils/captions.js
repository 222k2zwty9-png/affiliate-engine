module.exports = [
  "Nothing worked… until I fixed this. 👇",
  "I didn’t believe it either — but wow.",
  "If you're struggling with cravings, try this 💚",
  "Your gut controls more than you think.",
  "A simple morning step changed everything.",
  "This was the missing piece for me.",
  "Not another diet… something deeper.",
  "Real change started when I fixed my gut.",
  "Wish I knew this earlier.",
  "My metabolism finally responded."
];