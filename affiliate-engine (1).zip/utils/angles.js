module.exports = [
  "The discovery that rebalances gut bacteria so your body finally listens.",
  "Why millions can't lose weight: Gut bacteria imbalance.",
  "The capsule that supports digestion and metabolism naturally.",
  "A morning habit that boosts gut health and energy.",
  "Reduce cravings by nourishing your gut flora.",
  "Researchers now understand why dieting alone doesn’t work.",
  "The hidden gut connection to slow metabolism.",
  "Support gut health → support weight goals.",
  "Your gut bacteria might be working against you.",
  "The easiest daily step for gut wellness."
];