module.exports = (req, res) => {
  const hoplink = "https://a8ddfdvhw3q9prdff9x1tbr681.hop.clickbank.net/?&traffic_source=tiktok1";
  res.writeHead(302, { Location: hoplink });
  res.end();
};