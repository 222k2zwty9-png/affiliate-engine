const { generateContent } = require("./contentAgent");

module.exports = (req, res) => {
  const post = generateContent();
  console.log("Scheduled content generated:", post);
  res.json({
    status: "cron-ran",
    generated: post
  });
};