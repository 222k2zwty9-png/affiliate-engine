const { generateContent } = require("./contentAgent");

module.exports = async (req, res) => {
  const post = generateContent();
  console.log("Generated content:", post);
  return res.json({
    status: "ready",
    message: "Content generated for posting.",
    data: post
  });
};