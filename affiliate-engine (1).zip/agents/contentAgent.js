const angles = require("../utils/angles");
const captions = require("../utils/captions");
const hashtags = require("../utils/hashtags");

module.exports.generateContent = () => {
  const angle = angles[Math.floor(Math.random() * angles.length)];
  const caption = captions[Math.floor(Math.random() * captions.length)];
  const tagSet = hashtags.sort(() => 0.5 - Math.random()).slice(0, 5);

  return {
    script: angle,
    caption: caption + " " + tagSet.join(" "),
    postTime: new Date().toISOString()
  };
};